<?php
class AccountController {
    public function __construct() {
        die('Account controller');
    }
}
?>