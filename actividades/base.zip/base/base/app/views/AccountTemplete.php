<?php
class AccountTemplate {
    public function __construct() {
        die('Account template');
    }
}
?>