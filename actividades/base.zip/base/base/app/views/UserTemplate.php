<?php
class UserTemplate {
    public function __construct() {
        die('User template');
    }
}
?>