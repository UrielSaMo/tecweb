<?php
    require_once __DIR__ . '/app/models/User.php';
    require_once __DIR__ . '/app/views/UserTemplate.php';
    require_once __DIR__ . '/app/controllers/UserController.php';
    require_once __DIR__ . '/app/models/Account.php';
    require_once __DIR__ . '/app/controllers/AccountController.php';
    require_once __DIR__ . '/app/views/AccountTemplete.php';
    $user = new Account();
    // $user = new User();
    // $user = new UserController.();
?>