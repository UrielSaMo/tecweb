<?php
    require_once __DIR__ . '/app/start.php';
    $user = new Account();
    // $user = new User();
    // $user = new UserController.();
?>