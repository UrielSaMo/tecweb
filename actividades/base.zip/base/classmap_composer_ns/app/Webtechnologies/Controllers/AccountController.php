<?php
namespace Webtechlogies\Controllers;
class AccountController {
    public function __construct() {
        die('Account controller');
    }
}
?>