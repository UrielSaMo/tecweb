<?php
namespace Webtechlogies\Controllers;
class UserController {
    public function __construct() {
        die('User controller');
    }
}
?>