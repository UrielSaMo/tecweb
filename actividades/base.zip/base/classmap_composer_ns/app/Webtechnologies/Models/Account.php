<?php
namespace Webtechlogies\Models;
class Account {
    public function __construct() {
        die('Account model');
    }
}
?>