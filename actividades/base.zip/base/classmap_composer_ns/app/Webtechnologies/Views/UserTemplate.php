<?php
namespace Webtechlogies\Views;
class UserTemplate {
    public function __construct() {
        die('User template');
    }
}
?>