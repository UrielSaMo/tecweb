<?php
    use Webtechlogies\Views\AccountTemplate as AccountTemplate;
    require_once __DIR__ . '/app/start.php';
    $user = new  AccountTemplate();
    // $user = new User();
    // $user = new UserController.();
?>