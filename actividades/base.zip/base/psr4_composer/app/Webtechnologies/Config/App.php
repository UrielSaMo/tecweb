<?php
namespace Webtechlogies\Config;
    class App{
        public function __construct(){
            die('App config');
        
        
            
        }
    }
?>