<?php
namespace Webtechlogies\Config;
    class Dev{
        public function __construct(){
            die('Dev config');
        
        
            
        }
    }
?>