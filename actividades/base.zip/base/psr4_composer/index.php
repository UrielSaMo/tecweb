<?php
    use Webtechlogies\Config\App as App;
    require_once __DIR__ . '/app/start.php';
    $user = new  App();
    // $user = new User();
    // $user = new UserController.();
?>